//
//  AnnotationView.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 19-06-23.
//

import Foundation
import MapKit

class AnnotationView: MKMarkerAnnotationView {

    override var annotation: MKAnnotation? {
       
        willSet {
            guard let value = newValue as? Annotation else {return}
            detailCalloutAccessoryView = Callout(annotation: value)
        }
    }
}

