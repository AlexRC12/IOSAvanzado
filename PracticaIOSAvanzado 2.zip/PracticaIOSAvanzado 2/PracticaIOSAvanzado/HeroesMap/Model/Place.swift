//
//  Place.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 19-06-23.
//

import Foundation

struct Place {
    let name: String
    let latitude: Double
    let longitude: Double
    let image: String
}
