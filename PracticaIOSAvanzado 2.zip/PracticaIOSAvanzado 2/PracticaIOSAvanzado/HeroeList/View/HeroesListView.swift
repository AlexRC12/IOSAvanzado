//
//  HeroesListView.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 14-06-23.
//

import Foundation
import UIKit

class HeroesListView: UIView {
        
    
    let heroesTableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.register(HeroesListViewCell.self, forCellReuseIdentifier: "CellID")
        return tableView
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupView(){
        backgroundColor = .white
       
        addSubview(heroesTableView)
        
        NSLayoutConstraint.activate([
            
            heroesTableView.topAnchor.constraint(equalTo: topAnchor),
            heroesTableView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -20),
            heroesTableView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            heroesTableView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            
            
        ])
            
            
        
    }
    
    
}
