//
//  HeroesDetailViewModel.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 17-06-23.
//

import Foundation
import UIKit

class HeroDetailViewModel: NSObject {
    
    
    let token = KeyChain().readToken()
    private var apiClient: ApiClient?
    
    override init(){
        self.apiClient = ApiClient(token: token)
    }
    
    var updateUI:((_ hero: HeroModel?, _ error: String) -> Void)?
    
    func getDataForASpecificHero(name: String){
        guard let apiClient = self.apiClient else {return}
        
        apiClient.getHeroByName(name: name) { [weak self] hero, error in
            guard error == nil else {
                self?.updateUI?(nil, "Se produjo un error al obtener el detalle del heroe")
                return
            }
            
            
            guard let hero = hero else {
                self?.updateUI?(nil, "Se produjo un error al obtener el detalle del heroe")
                return
            }
            
            self?.updateUI?(hero,"")
            
            
        }
        
    }
    
    
}
