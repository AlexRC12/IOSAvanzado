//
//  HeroesListViewCell.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 15-06-23.
//

import Foundation
import UIKit
import Kingfisher

class HeroesListViewCell: UITableViewCell {
    
    let heroeImageView: UIImageView = {
       let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints=false
        return imageView
    }()
    
    let heroeName: UILabel = {
       let label = UILabel()
        label.font = UIFont.boldSystemFont(ofSize: 17)
        label.numberOfLines = 0
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    
    let heroeDescription: UILabel = {
       let label = UILabel()
        label.numberOfLines = 3
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier:String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func setupViews(){
        addSubview(heroeImageView)
        addSubview(heroeName)
        addSubview(heroeDescription)
        
        NSLayoutConstraint.activate([
            heroeImageView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            heroeImageView.topAnchor.constraint(equalTo: topAnchor, constant: 12),
            heroeImageView.heightAnchor.constraint(equalToConstant: 80),
            heroeImageView.widthAnchor.constraint(equalToConstant: 80),
            
            heroeName.leadingAnchor.constraint(equalTo: heroeImageView.trailingAnchor, constant: 10),
            heroeName.topAnchor.constraint(equalTo: heroeImageView.topAnchor),

            heroeDescription.leadingAnchor.constraint(equalTo: heroeName.leadingAnchor),
            heroeDescription.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            heroeDescription.topAnchor.constraint(equalTo: heroeName.bottomAnchor, constant: 8)
        ])
    }
    
    
    func configure(_ model: HeroModel) {
        self.heroeName.text = model.name 
        self.heroeDescription.text = model.description
        self.heroeImageView.kf.setImage(with: URL(string: model.photo))
    }

    
    
}
