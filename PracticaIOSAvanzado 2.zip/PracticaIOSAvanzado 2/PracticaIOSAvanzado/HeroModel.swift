//
//  HeroModel.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation

struct HeroModel: Decodable {
    let photo: String
    let id: String
    let favorite: Bool
    let name: String
    let description: String
    var latitude: Double?
    var longitude: Double?
}
