//
//  HeroesListViewModel.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 14-06-23.
//

import Foundation
import UIKit

class HeroesListViewModel: NSObject {
    
    let token = KeyChain().readToken()
    private var apiClient:ApiClient?

    override init(){
        self.apiClient = ApiClient(token: token)
    }
    
    
    var updateUI: ((_ heroesList:[HeroModel])->Void)?
    
    
    private var updateFullItems: ((_ heroesList: [HeroModel]) -> Void)?
    
    
    func getData(){
        
        guard let apiClient = self.apiClient else {return}
        
        apiClient.getHeroes { [weak self] heroes, error in
            self?.updateFullItems?(heroes)
        }
        

        updateFullItems = { (heroes: [HeroModel]) -> Void in
            var fullItems: [HeroModel] = []
            
            let group = DispatchGroup()
            
            for hero in heroes {
                group.enter()
                
                apiClient.getLocalization(with: hero.id) { heroLocations, error in
                    var fullHero = hero
                    if let firstLocation = heroLocations.first {
                        fullHero.latitude = Double(firstLocation.latitud)
                        fullHero.longitude = Double(firstLocation.longitud)
                    } else {
                        fullHero.latitude = 0.0
                        fullHero.longitude = 0.0
                    }
                    fullItems.append(fullHero)
                    group.leave()
                }
            }
            
            group.notify(queue: .main) {
                
                self.updateUI?(fullItems)  
                debugPrint("Los heroes son \(fullItems)")
            }
        }

        


    }
    
    
}
