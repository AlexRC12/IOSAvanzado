//
//  LoginViewModel.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation
import UIKit

class LoginViewModel:NSObject {
    
    var token = ""
    
    var tokenLoginViewModel: ((_ token: String, _ error: String)->Void)?
    
    
    func login(email: String, password: String){
        ApiClient(token: "").login(user: email, password: password) { [weak self] token, error in
            
            //debugPrint("El token del usuario es \(token ?? "")" )
            debugPrint(error ?? "")
            
            if let token = token {
                self?.token = token
                self?.tokenLoginViewModel?(token,"")
            }
            
            if let error = error {
                self?.tokenLoginViewModel?("", error.localizedDescription)
            }
            
        }
    }
    
}
