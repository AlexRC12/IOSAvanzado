//
//  prueba.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 18-06-23.
//

import Foundation
import UIKit

class Prueba: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .yellow
    }
}
