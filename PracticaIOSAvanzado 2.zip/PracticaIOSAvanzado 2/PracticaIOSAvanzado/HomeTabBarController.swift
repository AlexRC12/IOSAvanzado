//
//  HomeTabBarController.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 18-06-23.
//

import Foundation
import UIKit

class HomeTabBarController: UITabBarController {
    
    var loginViewController:LoginViewController?
    var heroesListViewController: HeroesListViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        AppState.token = KeyChain().readToken()
        debugPrint("El valor del token es \(AppState.token)")
        title = "Lista de heroes"
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .refresh, target: self, action: #selector(reloadB))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Logout", style: .plain, target: self, action: #selector(logoutB))
        
        setupTabs()
        
        
        if AppState.token.isEmpty {
            loginViewController = LoginViewController(delegate: self)
            
            if let loginViewController = loginViewController {
                loginViewController.modalPresentationStyle = .fullScreen
                self.navigationController?.present(loginViewController, animated: true)
                return
            }
            
        }
        
        reloadData()
    }
    
    private func reloadData() {
        NotificationCenter.default.post(name: Notification.Name("notificacion.reload.data"), object: nil)
    }
    
    @objc
    func logoutB(){
        
        debugPrint("el valor de keychain es \(KeyChain().readToken())")
        loginViewController = LoginViewController(delegate: self)
        
        if let loginViewController = loginViewController {
            loginViewController.modalPresentationStyle = .fullScreen
            self.navigationController?.present(loginViewController, animated: true)
            KeyChain().deleteToken()
            AppState.heroeList.removeAll() //OJO
            CoreDataHelper.removeData()
            debugPrint("El token es \(KeyChain().readToken())")
        }
    }

    //VOLVER!!!
    @objc
    func reloadB(){
        AppState.heroeList.removeAll()
        CoreDataHelper.removeData()
        debugPrint("Reload!!!")
        reloadData()
        

    }

    
    func setupTabs(){
        
        //Configuramos la lista de heroes que se mostrará en el tabBar
        let navHeroesListViewController = UINavigationController(rootViewController: HeroesListViewController())
        
        navHeroesListViewController.tabBarItem = UITabBarItem(title: "Lista", image: UIImage(systemName:"list.bullet"), tag: 0)
        
        //Configuramos el mapa de heroes que se mostrará en el tabBar
        let mapHeroesList = UINavigationController(rootViewController: MapViewController())
        
        mapHeroesList.tabBarItem = UITabBarItem(title: "Mapa", image: UIImage(systemName: "map.fill"), tag: 1)
        
        
        //Configuramos la tabBar y sus elementos
        setViewControllers([navHeroesListViewController, mapHeroesList], animated: true)
        tabBar.backgroundColor = .white
    }
    
    
    
}

extension HomeTabBarController: LoginDelegate {
    func dismiss() {
        debugPrint("dismiss en el loginviewcontrollerx")
        DispatchQueue.main.async {
            self.loginViewController?.dismiss(animated: true)
            
        }
    }
}
