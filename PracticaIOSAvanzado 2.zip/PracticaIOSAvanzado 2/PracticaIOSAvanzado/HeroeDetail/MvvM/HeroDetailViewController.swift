//
//  HeroesDetailViewController.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 17-06-23.
//

import Foundation
import UIKit

class HeroDetailViewController : UIViewController {
    var mainView: HeroDetailView {self.view as! HeroDetailView}
    
    private var heroModel:HeroModel?
    private var heroeDetailViewModel: HeroDetailViewModel?
    private var loginViewModel = LoginViewModel()
    
    init(heroModel: HeroModel){
        super.init(nibName: nil, bundle: nil)
        self.heroModel = heroModel
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        view = HeroDetailView()
    }
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        self.heroeDetailViewModel = HeroDetailViewModel()
        
        guard let hero = self.heroModel else {return}
        
        self.heroeDetailViewModel?.getDataForASpecificHero(name: hero.name)
        
        
        self.heroeDetailViewModel?.updateUI = { [weak self] heroModel, error in
            guard let heroModel = heroModel else {return}
            
            
            self?.getHeroDetails(heroDetailModel: heroModel)
            
        }
    }
      
    
    func getHeroDetails(heroDetailModel: HeroModel){
        DispatchQueue.main.async {
            self.mainView.configure(heroDetailModel)
        }
    }
    
}
