//
//  MapViewController.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 19-06-23.
//

import Foundation
import MapKit
import CoreLocation

class MapViewController: UIViewController {
    
   
    var mapView : MKMapView = {
        let map = MKMapView()
        map.overrideUserInterfaceStyle = .light
        return map
    }()
    
    var locationManager: CLLocationManager?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        setMapConstraints(mapView)
        
        locationManager = CLLocationManager()
        locationManager?.requestWhenInUseAuthorization()
        
        locationManager?.delegate = self
        mapView.showsUserLocation = true
        mapView.mapType = .standard
        
        mapView.delegate = self
        
        
        moveToCoordinates(initialLatitude, initialLongitude)
        
        
        mapView.register(AnnotationView.self, forAnnotationViewWithReuseIdentifier: MKMapViewDefaultAnnotationViewReuseIdentifier)
        
        mapView.register(CustomMaker.self, forAnnotationViewWithReuseIdentifier: "id2")
        
        
        renderAnnotationsInMap(mapView, AppState.heroeList)

        
    }
    
    
    func createAnnotation(_ place: Place) {
        
        let annotation = MKPointAnnotation()
        
        annotation.coordinate = CLLocationCoordinate2D(latitude: place.latitude, longitude: place.longitude)
        annotation.title = place.name
        annotation.subtitle = "Estás viendo \(place.name)"
        debugPrint("Estas viendo \(place.name)")
        mapView.addAnnotation(annotation)
    }
    
    
    func createAnnotations(_ places: [Place]) {
        
        places.forEach { place in
            createAnnotation(place)
        }
    }
  
    
    
    let initialLatitude = 51.0
    let initialLongitude = 10.0
    
    
    func moveToCoordinates(_ latitude: Double, _ longitude: Double) {
        
        let center = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        
        let span = MKCoordinateSpan(latitudeDelta: 40, longitudeDelta: 60)
        
        let region = MKCoordinateRegion(center: center, span: span)
        
        mapView.setRegion(region, animated: true)
        
    }
    
    
    private func renderAnnotationsInMap(_ mapView: MKMapView, _ heroes: [HeroModel]) {
        let annotations = heroes.map { Annotation(hero: $0) }
        
        mapView.showAnnotations(annotations, animated: true)
    }
    
    
    private func setMapConstraints(_ mapView: MKMapView) {
        view.addSubview(mapView)
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapView.topAnchor.constraint(equalTo: self.view.topAnchor).isActive = true
        mapView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        mapView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor).isActive = true
        mapView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor).isActive = true        
    }
    
}



extension MapViewController: MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        debugPrint("annotation -> \(annotation)")
        
        let id = MKMapViewDefaultAnnotationViewReuseIdentifier
        let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: id)
        
        if let annotation = annotation as? Annotation {
            annotationView?.canShowCallout = true
            annotationView?.detailCalloutAccessoryView = Callout(annotation: annotation)
            
            return annotationView
        }
        
        return nil
    }
    
}



extension MapViewController: CLLocationManagerDelegate {
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        
        if #available(iOS 14.0, *) {
            switch manager.authorizationStatus{
                
            case .notDetermined:
                debugPrint("Not Determined")
            case .restricted:
                debugPrint("Restricted")
            case .denied:
                debugPrint("Denied")
            case .authorizedAlways:
                debugPrint("Authorized Always")
            case .authorizedWhenInUse:
                debugPrint("Authorized when in use")
            @unknown default:
                debugPrint("Unknow Status")
            }
            
        }
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        switch manager.authorizationStatus{
            
        case .notDetermined:
            debugPrint("Not Determined")
        case .restricted:
            debugPrint("Restricted")
        case .denied:
            debugPrint("Denied")
        case .authorizedAlways:
            debugPrint("Authorized Always")
        case .authorizedWhenInUse:
            debugPrint("Authorized when in use")
        @unknown default:
            debugPrint("Unknow Status")
        }
    }
    
    
    
    
    
}
