//
//  Constants.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation

class Constants {
    static var api_base_url = "https://dragonball.keepcoding.education/api/"
}
