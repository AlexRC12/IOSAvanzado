//
//  LoginViewController.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation
import UIKit

protocol LoginDelegate {
    func dismiss()
    
}

class LoginViewController: UIViewController {
    
    var mainView: LoginView {self.view as! LoginView}  //seteo la vista personalizada
    var loginViewModel = LoginViewModel()  //Instancio LoginViewModel para usarlo
    
    var delegate: LoginDelegate?
    init(delegate: LoginDelegate){
        super.init(nibName: nil, bundle: nil)
        self.delegate = delegate
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    
    
   
    override func loadView() {
        view = LoginView()   //seteo la vista del controller como la personalizada
    }
    
    //Carga de elementos adicionales
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Acción del botón "Acceder"
        mainView.loginButton.addTarget(self, action: #selector(didLoginTapped), for: .touchUpInside)
        
        #if DEBUG
        
        mainView.emailTextField.text = "ariquelme@ing.ucsc.cl"
        mainView.passwordTextField.text = "Paviliondv6."
        
        #endif
    }
    
    
    @objc
    private func didLoginTapped(){
        guard let email = mainView.emailTextField.text, !email.isEmpty else {return}
        
        guard let password = mainView.passwordTextField.text, !password.isEmpty else {return}
        
        
        loginViewModel.login(email: email, password: password)
        
        
        loginViewModel.tokenLoginViewModel = { [weak self] token, error in
            guard let self else {return}
            
            AppState.token = token
            
            
            if !error.isEmpty{
                DispatchQueue.main.async {
                    self.mainView.errorMessageLabel.text = "Error al hacer login, no se logró obtener un token"
                }
                return
            }
            
            
            if !token.isEmpty{
                
                KeyChain().saveToken(token: token)
                debugPrint("El token almacenado globalmente es \(AppState.token)")
                DispatchQueue.main.async {
                    
                    self.dismiss(animated: true) 
                }
            }
            NotificationCenter.default.post(name: NSNotification.Name( "notification.login.result"), object: nil)

            
        }
       
    }
    
    
    
}
