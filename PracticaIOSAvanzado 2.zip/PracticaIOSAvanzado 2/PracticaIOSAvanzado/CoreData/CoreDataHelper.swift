//
//  CoreDataHelper.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 22-06-23.
//

import Foundation
import CoreData

class CoreDataHelper {
    static var context = AppDelegate.sharedAppDelegate.coreDataManager.managedContext
    
    static func saveData(_ heroes: [HeroModel]) {   
        heroes.forEach(saveItem)
    }
    
    private static func saveItem(_ hero: HeroModel) {
        let heroDB = Hero(context: context)
        
        
        heroDB.id = hero.id
        heroDB.name = hero.name
        heroDB.favorite = hero.favorite
        heroDB.details = hero.description
        heroDB.photo = hero.photo
        heroDB.latitude = hero.latitude ?? 0.0
        heroDB.longitude = hero.longitude ?? 0.0
        
        
        do {
            
            try context.save()
            
        } catch let error {
            debugPrint(error)
        }
    }
    
    
    
    static func getData() -> [HeroModel] {
        let heroFetch: NSFetchRequest<Hero> = Hero.fetchRequest()
        
        do {
            let result = try context.fetch(heroFetch)
            let heroes = result.map {
                HeroModel.init(photo: $0.photo ?? "",
                               id: $0.id,
                               favorite: $0.favorite,
                               name: $0.name,
                               description: $0.details,
                               latitude: $0.latitude,
                               longitude: $0.longitude)
            }
            
            return heroes
            
        } catch let error as NSError {
            debugPrint("Error -> \(error)")
            return []
        }
        
    }
    
    
    
    private static func getDataFromDB() -> [Hero] {
        let heroFetch: NSFetchRequest<Hero> = Hero.fetchRequest()
        
        do {
            let result = try context.fetch(heroFetch)
            
            debugPrint("Result de la función getDataFromBD es \(result.count)")
            return result
            
        } catch let error as NSError {
            debugPrint("Error -> \(error)")
            return []
        }
    }
    
   
    static func removeData() {
        
        var heroes = getDataFromDB()
        
        debugPrint("PMG antes \(heroes.count)")
        
        heroes.forEach(removeItem)
        heroes = getDataFromDB()
        debugPrint("PMG despues \(heroes.count)")
    }
    
    private static func removeItem(_ hero: Hero) {
        
        context.delete(hero)
                
        
        AppDelegate.sharedAppDelegate.coreDataManager.saveContext()
    }
}

