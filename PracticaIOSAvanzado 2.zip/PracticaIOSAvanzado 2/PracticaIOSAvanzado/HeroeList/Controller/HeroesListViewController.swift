//
//  HeroesListViewController.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 14-06-23.
//

import Foundation
import UIKit

class HeroesListViewController: UIViewController {
    
    var mainView: HeroesListView {self.view as! HeroesListView}
    var heroesList:[HeroModel] = []
    private var tableViewDataSource: HeroesListTableViewDataSource?
    private var tableViewDelegate: HeroesListTableViewDelegate?
    private var heroeListViewModel: HeroesListViewModel?
    private var loginViewModel = LoginViewModel()
    
    private var loginViewController:LoginViewController?

    
    override func loadView() {
        view = HeroesListView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        addNotification()

        
        //Configura los elementos de la tabla
        setTableElements()
        //Configura la función que indica que celda se pulso
        didTappedCell()
        //Preguntamos si existe un token o no.
        AppState.token = KeyChain().readToken()
        
        if AppState.token.isEmpty {
            loginViewController = LoginViewController(delegate: self)
            
            if let loginViewController = loginViewController {
                loginViewController.modalPresentationStyle = .fullScreen
                self.navigationController?.present(loginViewController, animated: true)
                
            }
        }

        getData()
    }
    
    
    
    //Configuramos el delegate y datasource de la tabla
    private func setTableElements(){
        tableViewDelegate = HeroesListTableViewDelegate()
        mainView.heroesTableView.delegate = tableViewDelegate
        
        tableViewDataSource = HeroesListTableViewDataSource(tableView: mainView.heroesTableView)
        mainView.heroesTableView.dataSource = tableViewDataSource
    }
    
    
    //Configuramos el comportamiento de lo que pase cuando se pulse en la celda
    func didTappedCell(){
        tableViewDelegate?.didTapOnCell = { [weak self] index in
            
            guard let datasource = self?.tableViewDataSource else {return}
            
            let hero = datasource.heroes[index]
            debugPrint("Se pulsa en el heroe \(hero.name)")
            let heroDetailViewController = HeroDetailViewController(heroModel: hero)
            
            self?.present(heroDetailViewController, animated: true)
        }
    }
    
    
    func addNotification(){
        
        NotificationCenter.default.addObserver(self, selector: #selector(reloadData(_:)), name:NSNotification.Name( "notificacion.reload.data"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(loginResult(_:)), name: NSNotification.Name("notification.login.result"), object: nil)
        
    }
  
    
    @objc
    func loginResult(_:Notification){
        debugPrint("Se hizo login ok")
        getData()
        
    }
    
    @objc
    func reloadData(_:Notification){
        debugPrint("Llego la llamada desde reload")
        getData()
    }
    
    
    func getData() {
        
        AppState.heroeList = CoreDataHelper.getData()
        debugPrint("Los datos almacenados en coredata son \(AppState.heroeList.count)")
        
        if AppState.heroeList.isEmpty {
            getDataApi()
            
            return
        }
        populateTable(heroes: AppState.heroeList)
    }
    
    
    
    func getDataApi() {
       
        heroeListViewModel = HeroesListViewModel()
        
        
        guard let heroeListViewModel else {return}
        
        
        heroeListViewModel.getData()
        
        
        heroeListViewModel.updateUI = { [weak self] heroes in
           
            CoreDataHelper.saveData(heroes)
            AppState.heroeList = CoreDataHelper.getData()
            
            self?.tableViewDataSource?.set(heroes: heroes)
            
        }
    }
    
    private func populateTable(heroes: [HeroModel]) {
        self.tableViewDataSource?.set(heroes: heroes)
    }
}


extension HeroesListViewController: LoginDelegate {
    func dismiss() {
        debugPrint("dismiss en el loginviewcontroller")
        
        DispatchQueue.main.async {
            self.loginViewController?.dismiss(animated: true)
          
        }
    }
}
