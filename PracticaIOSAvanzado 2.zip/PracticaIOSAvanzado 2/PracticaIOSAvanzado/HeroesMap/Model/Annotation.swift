//
//  Annotation.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 19-06-23.
//

import Foundation
import MapKit

class Annotation: NSObject, MKAnnotation {
    
    
    let coordinate: CLLocationCoordinate2D
    let name:String
    let image: String              
    let id: String
        
    
    init(hero: HeroModel) {
        coordinate = CLLocationCoordinate2D(latitude: hero.latitude ?? 0.0, longitude: hero.longitude ?? 0.0)
        name = hero.name
        image = hero.photo
        id = hero.id
        
    }
    
}
