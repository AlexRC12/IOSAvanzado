//
//  CustomMaker.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 19-06-23.
//

import Foundation
import UIKit
import MapKit

class CustomMaker: MKAnnotationView {
    override var annotation: MKAnnotation? {  //Sobreescribimos el marcador por defector que tiene la clase MKAnnotation
        willSet {
            let pinImage = UIImage(named: "marker-blue")
            let size = CGSize(width: 40, height: 40)
            UIGraphicsBeginImageContext(size)
            pinImage!.draw(in: CGRect(x: 0, y: 0, width: size.width, height: size.height))
            
            let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
            
            //Añadimos imagen
            self.image = resizedImage
            
            
        }
        
        
    }
    
}
