//
//  HeroLocationModel.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 18-06-23.
//

import Foundation


struct HeroLocationModel: Decodable {
    let id: String
    let latitud: String
    let longitud: String
    
}
