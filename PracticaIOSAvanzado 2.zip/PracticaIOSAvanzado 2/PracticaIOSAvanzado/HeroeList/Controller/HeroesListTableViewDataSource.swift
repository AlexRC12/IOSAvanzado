//
//  HeroesListTableViewDataSource.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 15-06-23.
//

import Foundation
import UIKit

final class HeroesListTableViewDataSource: NSObject, UITableViewDataSource {

    private let tableView: UITableView
    
    
    // Cada vez que la lista de héroes cambie, se actualizará la tabla
    private(set) var heroes: [HeroModel] = [] {
        didSet {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }
    
    init(tableView: UITableView, heroes: [HeroModel] = []) {
        self.tableView = tableView
        self.heroes = heroes
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        heroes.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath) as! HeroesListViewCell
        
        let hero = heroes[indexPath.row]
        cell.configure(hero)
        
        return cell
    }
    
    func set(heroes: [HeroModel]) {
        self.heroes = heroes
    }
    
}
