//
//  ApiClient.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation

enum NetworkError: Error {
  case malformedURL
  case noData
  case statusCode(code: Int?)
  case decodingFailed
  case unknown
}

final class ApiClient {
    
    private var token: String?
    
    convenience init(token: String) {
        self.init()
        self.token = token
    }
    
    func login(user: String, password: String, completion: @escaping (String?, Error?) -> Void) {
        guard let url = URL(string: "\(Constants.api_base_url)/auth/login") else {
            completion(nil, NetworkError.malformedURL)
            return
        }
        
        let loginString = String(format: "%@:%@", user, password)
        let loginData = loginString.data(using: String.Encoding.utf8)!
        let base64LoginString = loginData.base64EncodedString()
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard error == nil else {
                completion(nil, NetworkError.unknown)
                return
            }
            
            guard let data = data else {
                completion(nil, NetworkError.noData)
                return
            }
            
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {
                completion(nil, NetworkError.statusCode(code: (response as? HTTPURLResponse)?.statusCode))
                return
            }
            
            guard let response = String(data: data, encoding: .utf8) else {
                completion(nil, NetworkError.decodingFailed)
                return
            }
            
            self.token = response
            completion(response, nil)
        }
        
        task.resume()
    }
    
    func getHeroes(completion: @escaping ([HeroModel], Error?) -> Void) {
        guard let url = URL(string: "\(Constants.api_base_url)/heros/all"), let token = self.token else {
            completion([], NetworkError.malformedURL)
            return
        }
        
        var urlComponents = URLComponents()
        urlComponents.queryItems = [URLQueryItem(name: "name", value: "")]
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        urlRequest.httpBody = urlComponents.query?.data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard error == nil else {
                completion([], NetworkError.unknown)
                return
            }
            
            guard let data = data else {
                completion([], NetworkError.noData)
                return
            }
            
            guard let response = try? JSONDecoder().decode([HeroModel].self, from: data) else {
                completion([], NetworkError.decodingFailed)
                return
            }
            completion(response, nil)
        }
        
        task.resume()
    }
    
    func getHeroByName(name: String, completion: @escaping (HeroModel?, Error?) -> Void) {
        guard let url = URL(string: "\(Constants.api_base_url)/heros/all"), let token = self.token else {
            completion(nil, NetworkError.malformedURL)
            return
        }
        
        var urlComponents = URLComponents()
        urlComponents.queryItems = [URLQueryItem(name: "name", value: name)]
        
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        urlRequest.httpBody = urlComponents.query?.data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            guard error == nil else {
                completion(nil, NetworkError.unknown)
                return
            }
            
            guard let data = data else {
                completion(nil, NetworkError.noData)
                return
            }
            
            guard let response = try? JSONDecoder().decode([HeroModel].self, from: data) else {
                completion(nil, NetworkError.decodingFailed)
                return
            }
            completion(response.first, nil)
        }
        
        task.resume()
    }
    
    
    //Función para obtener la localización del heroe, dado in "id" proporcionado al llamar a la función
    func getLocalization(with id: String, completion: @escaping ([HeroLocationModel], Error?) -> Void) {
        //Se comprueba que la url sea válida y que exista el token
        guard let url = URL(string: "\(Constants.api_base_url)/heros/locations"), let token = self.token else {
            completion([], NetworkError.malformedURL)
            return
        }
        
        //Se formula la query utilizando el id como componente de la consulta.
        var urlComponents = URLComponents()
        urlComponents.queryItems = [URLQueryItem(name: "id", value: id)]
        
        //Se utiliza el método "POST" para realizar la llamada a la API
        var urlRequest = URLRequest(url: url)
        urlRequest.httpMethod = "POST"
        urlRequest.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        urlRequest.httpBody = urlComponents.query?.data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            //Se comprueba que el error sea "nil" sino devuelve error "NetworkError.unknown" en el completion
            guard error == nil else {
                completion([], NetworkError.unknown)
                return
            }
            
            //Desempaqueta de forma segura la data, sino devuelve error "NetworkError.noData" en el completion
            guard let data = data else {
                completion([], NetworkError.noData)
                return
            }
            
            //Decodifica el json a un array de tipo "HeroLocationModel", sino devuelve error "NetworkError.decodingFailed"
            guard let response = try? JSONDecoder().decode([HeroLocationModel].self, from: data) else {
                completion([], NetworkError.decodingFailed)
                return
            }
            
            //Si todo ha ido bien entrega response al completion para que se pueda usar 
            completion(response, nil)
        }
        
        task.resume()
    }
     
    
}
