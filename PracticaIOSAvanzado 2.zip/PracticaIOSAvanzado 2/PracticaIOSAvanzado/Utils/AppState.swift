//
//  AppState.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation

class AppState {
    
    static var token = ""
    
    static var heroeList: [HeroModel] = []
}
