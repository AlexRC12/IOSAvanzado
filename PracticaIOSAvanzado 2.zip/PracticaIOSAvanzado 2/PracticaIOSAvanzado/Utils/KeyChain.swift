//
//  KeyChain.swift
//  PracticaIOSAvanzado
//
//  Created by Alex Riquelme on 13-06-23.
//

import Foundation
import Security

class KeyChain{
    
    
    
    //Para guardar el token
    func saveToken(token:String) {
        
        let attributes: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "UserToken",
            kSecValueData as String: token.data(using: .utf8)!
        ]
        
        if SecItemAdd(attributes as CFDictionary, nil) == noErr {
            debugPrint("Información del usuario guardada con éxito")
        } else {
            debugPrint("Se produjo un error al guardar la información del usuario saveToken")
        }
        
    }
    
    //Para consultar el token
    
    func readToken() -> String {
        
        // Preparamos la consulta
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "UserToken",
            kSecMatchLimit as String: kSecMatchLimitOne,
            kSecReturnAttributes as String: true,
            kSecReturnData as String: true
        ]
        
        var item: CFTypeRef?
        
        if SecItemCopyMatching(query as CFDictionary, &item) == noErr {
            
            // extraemos la información
            if let existingItem = item as? [String: Any],
               let UserToken = existingItem[kSecAttrAccount as String] as? String,
               let UserTokenData = existingItem[kSecValueData as String] as? Data,
               let token = String(data: UserTokenData, encoding: .utf8) {
                //debugPrint("Token obtenido con exito")
                //debugPrint(UserToken)   //Nombre de la variable con la que se guardó el userToken
                //debugPrint(token)  //Token guardado previamente descodificado
                return token
            }
            
        }
        
        return ""
    }
    
    //Para eliminar el token
    
    func deleteToken(){
        let UserToken = "UserToken"
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: UserToken
        ]
        
        if (SecItemDelete(query as CFDictionary)) == noErr{
            debugPrint("Información del usuario eliminada con éxito")
        } else {
            debugPrint("Se produjo un error al eliminar la información del usuario deleteToken")
        }
        
    }
    
    
    //Para actualizar el token
    
    func updateToken(token:String){
    
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "UserToken"
        ]
        
        
        let attributes: [String: Any] = [
            kSecValueData as String: token.data(using: .utf8)!
        ]
        
        if (SecItemUpdate(query as CFDictionary, attributes as CFDictionary)) == noErr {
            debugPrint("Información del usuario actualizada con éxito")
        } else {
            debugPrint("Se produjo un error al actualizar la información del usuario updateToken")
        }
        
    }
    
    
}
